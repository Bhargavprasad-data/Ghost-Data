import os
import shutil
import json

src_dir = r"C:\Users\Bharg\.gemini\antigravity-ide\brain\b651d714-9e3c-4d39-9214-e9406e6ed059\.system_generated\logs"
src_full = os.path.join(src_dir, "transcript_full.jsonl")
dest_root = r"C:\Users\Bharg\OneDrive\Desktop\OST"
dest_jsonl = os.path.join(dest_root, "chat_transcript.jsonl")
dest_readable = os.path.join(dest_root, "chat_transcript_readable.txt")

# 1. Copy raw JSONL directly
shutil.copy2(src_full, dest_jsonl)
print(f"Copied raw transcript to: {dest_jsonl} ({os.path.getsize(dest_jsonl)} bytes)")

# 2. Generate a human-readable clean export
readable_lines = [
    "=" * 80,
    "GHOST DATA STILL EXISTS — COMPLETE CHAT TRANSCRIPT EXPORT",
    f"Session ID: b651d714-9e3c-4d39-9214-e9406e6ed059",
    f"Source: {src_full}",
    "=" * 80,
    ""
]

with open(src_full, "r", encoding="utf-8") as f:
    for idx, line in enumerate(f, 1):
        if not line.strip():
            continue
        try:
            entry = json.loads(line)
            etype = entry.get("type", "")
            ts = entry.get("created_at", "")
            step_idx = entry.get("step_index", idx)

            if etype == "USER_INPUT":
                content = entry.get("content", "").strip()
                readable_lines.append("\n" + "=" * 80)
                readable_lines.append(f"[{ts}] USER (Step {step_idx}):")
                readable_lines.append("-" * 40)
                readable_lines.append(content)
                readable_lines.append("=" * 80 + "\n")
            elif etype == "PLANNER_RESPONSE":
                content = entry.get("content", "").strip()
                tools = entry.get("tool_calls", [])
                readable_lines.append(f"[{ts}] ASSISTANT (Step {step_idx}):")
                if content:
                    readable_lines.append(content)
                if tools:
                    readable_lines.append("\nTool Invocations:")
                    for t in tools:
                        tname = t.get("name", "")
                        args = t.get("args", {})
                        summary = args.get("toolSummary", "") or args.get("CommandLine", "") or args.get("TargetFile", "") or args.get("AbsolutePath", "")
                        readable_lines.append(f"  • {tname}: {summary}")
                readable_lines.append("-" * 40)
        except Exception:
            pass

with open(dest_readable, "w", encoding="utf-8") as f:
    f.write("\n".join(readable_lines))

print(f"Generated readable transcript at: {dest_readable} ({os.path.getsize(dest_readable)} bytes, {len(readable_lines)} lines)")
