# Scratchpad: Ghost Data Forensics Console UI Review

- [ ] Open http://localhost:8000
- [ ] Wait for page load
- [ ] Capture screenshot of current Postman-inspired UI
- [ ] Summarize findings and return screenshot artifact
