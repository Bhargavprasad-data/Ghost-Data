# Browser Task Scratchpad - Ghost Data Still Exists UI Verification

## Checklist
- [x] 1. Open `http://127.0.0.1:8000` and inspect layout (68px left rail, Lucide icons, main dashboard).
- [x] 2. Hover over sidebar, verify smooth expansion to 260px without shifting main dashboard content.
- [x] 3. Move mouse off sidebar, verify smooth collapse to 68px icon rail.
- [ ] 4. Click 'Case Explorer', verify search bar, dataset switchers, status chips, table.
- [ ] 5. Search for 'case_33', click inspect button (eye icon) to open Case Dossier Drawer.
- [ ] 6. Verify drawer slides out smoothly, showing Identity Resolution, Request Intent, Timestamps, Steps. Close drawer.
- [ ] 7. Click 'Sample Benchmark', verify benchmark accuracy metrics.
- [ ] 8. Click 'Evidence Files', verify file catalog and content preview.
- [ ] 9. Capture final screenshots and report findings.
